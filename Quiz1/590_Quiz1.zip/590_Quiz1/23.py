import pandas as pd
import plotly.express as px

df = pd.read_csv('23.csv')

fig = px.line(df, x = 'SampleDate', y = 'Result_Value', title = "PB_UGL")
fig.show()