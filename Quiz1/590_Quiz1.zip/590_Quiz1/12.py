import pandas as pd
import plotly.express as px

df = pd.read_csv('12.csv')

fig = px.line(df, x = 'SampleDate', y = 'Result_Value', title = "SUCRALOSE_UG/L")
fig.show()