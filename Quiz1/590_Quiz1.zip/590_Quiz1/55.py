import pandas as pd
import plotly.express as px

df = pd.read_csv('55.csv')

fig = px.line(df, x = 'SampleDate', y = 'Result_Value', title = "C_ORGANIC_MGL")
fig.show()