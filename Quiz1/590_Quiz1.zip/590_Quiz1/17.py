import pandas as pd
import plotly.express as px

df = pd.read_csv('17.csv')

fig = px.line(df, x = 'SampleDate', y = 'Result_Value', title = "SECCHI_FT")
fig.show()