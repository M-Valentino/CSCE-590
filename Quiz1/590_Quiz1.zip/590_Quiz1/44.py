import pandas as pd
import plotly.express as px

df = pd.read_csv('44.csv')

fig = px.line(df, x = 'SampleDate', y = 'Result_Value', title = "FE_UGL")
fig.show()