import pandas as pd
import plotly.express as px

df = pd.read_csv('57.csv')

fig = px.line(df, x = 'SampleDate', y = 'Result_Value', title = "COLOR_TRUE_PCU")
fig.show()