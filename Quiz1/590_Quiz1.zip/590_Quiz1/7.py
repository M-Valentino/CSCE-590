import pandas as pd
import plotly.express as px

df = pd.read_csv('7.csv')

fig = px.line(df, x = 'SampleDate', y = 'Result_Value', title = "TL_UGL")
fig.show()