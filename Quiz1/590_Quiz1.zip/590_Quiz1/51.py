import pandas as pd
import plotly.express as px

df = pd.read_csv('51.csv')

fig = px.line(df, x = 'SampleDate', y = 'Result_Value', title = "DEPTH_BOTT_FT")
fig.show()