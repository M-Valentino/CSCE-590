#!/bin/bash
gawk -vFPAT='[^,]*|"[^"]*"' '{print $13}' WaterAtlas-OneLake.csv | tr "[a-z]" "[A-Z]" | tr -d '"' |sort | uniq -i | sort -nr > unique_parameters.txt
