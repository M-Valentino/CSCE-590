import pandas as pd
import plotly.express as px

df = pd.read_csv('30.csv')

fig = px.line(df, x = 'SampleDate', y = 'Result_Value', title = "NH3_N_UGL")
fig.show()