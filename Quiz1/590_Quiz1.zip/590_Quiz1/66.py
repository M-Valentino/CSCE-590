import pandas as pd
import plotly.express as px

df = pd.read_csv('66.csv')

fig = px.line(df, x = 'SampleDate', y = 'Result_Value', title = "B_UGL")
fig.show()