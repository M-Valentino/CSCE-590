import pandas as pd
import plotly.express as px

df = pd.read_csv('27.csv')

fig = px.line(df, x = 'SampleDate', y = 'Result_Value', title = "NO3_DISS_UGL")
fig.show()