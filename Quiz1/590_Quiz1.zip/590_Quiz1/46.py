import pandas as pd
import plotly.express as px

df = pd.read_csv('46.csv')

fig = px.line(df, x = 'SampleDate', y = 'Result_Value', title = "ENDOTHALL_UGL")
fig.show()