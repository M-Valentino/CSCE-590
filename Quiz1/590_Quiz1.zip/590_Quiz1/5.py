import pandas as pd
import plotly.express as px

df = pd.read_csv('5.csv')

fig = px.line(df, x = 'SampleDate', y = 'Result_Value', title = "TOC_MGL")
fig.show()