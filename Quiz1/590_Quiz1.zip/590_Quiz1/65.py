import pandas as pd
import plotly.express as px

df = pd.read_csv('65.csv')

fig = px.line(df, x = 'SampleDate', y = 'Result_Value', title = "CA_DISS_MGL")
fig.show()