import pandas as pd
import plotly.express as px

df = pd.read_csv('2.csv')

fig = px.line(df, x = 'SampleDate', y = 'Result_Value', title = "TURB_NTU")
fig.show()