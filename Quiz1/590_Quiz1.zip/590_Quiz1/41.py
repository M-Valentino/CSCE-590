import pandas as pd
import plotly.express as px

df = pd.read_csv('41.csv')

fig = px.line(df, x = 'SampleDate', y = 'Result_Value', title = "HARDNESSCARBONATE_MGL")
fig.show()