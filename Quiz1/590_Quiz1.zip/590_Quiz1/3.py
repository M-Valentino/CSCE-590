import pandas as pd
import plotly.express as px

df = pd.read_csv('3.csv')

fig = px.line(df, x = 'SampleDate', y = 'Result_Value', title = "TSS_MGL")
fig.show()