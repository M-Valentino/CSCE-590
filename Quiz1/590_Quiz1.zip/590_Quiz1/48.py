import pandas as pd
import plotly.express as px

df = pd.read_csv('48.csv')

fig = px.line(df, x = 'SampleDate', y = 'Result_Value', title = "DO_PERCENT")
fig.show()