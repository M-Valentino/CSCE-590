import pandas as pd
import plotly.express as px

df = pd.read_csv('43.csv')

fig = px.line(df, x = 'SampleDate', y = 'Result_Value', title = "F_MGL")
fig.show()