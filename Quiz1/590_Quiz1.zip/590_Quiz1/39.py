import pandas as pd
import plotly.express as px

df = pd.read_csv('39.csv')

fig = px.line(df, x = 'SampleDate', y = 'Result_Value', title = "LINURON_UGL")
fig.show()