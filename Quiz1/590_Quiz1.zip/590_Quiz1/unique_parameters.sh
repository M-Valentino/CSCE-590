#!/bin/bash
gawk -vFPAT='[^,]*|"[^"]*"' '{print $13}' WaterAtlas-OneLake.csv | tr "[a-z]" "[A-Z]" | tr -d '"' |sort | uniq -c | sort -nr > count_of_unique_parameters.txt
