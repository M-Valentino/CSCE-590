import pandas as pd
import plotly.express as px

df = pd.read_csv('25.csv')

fig = px.line(df, x = 'SampleDate', y = 'Result_Value', title = "OP_MGL")
fig.show()