import pandas as pd
import plotly.express as px

df = pd.read_csv('31.csv')

fig = px.line(df, x = 'SampleDate', y = 'Result_Value', title = "NH3_N_DISS_UGL")
fig.show()