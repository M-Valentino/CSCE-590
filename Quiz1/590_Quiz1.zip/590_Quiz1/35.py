import pandas as pd
import plotly.express as px

df = pd.read_csv('35.csv')

fig = px.line(df, x = 'SampleDate', y = 'Result_Value', title = "MN_DISS_UGL")
fig.show()