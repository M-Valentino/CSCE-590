import pandas as pd
import plotly.express as px

df = pd.read_csv('69.csv')

fig = px.line(df, x = 'SampleDate', y = 'Result_Value', title = "AS_UGL")
fig.show()