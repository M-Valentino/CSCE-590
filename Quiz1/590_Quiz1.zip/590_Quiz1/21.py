import pandas as pd
import plotly.express as px

df = pd.read_csv('21.csv')

fig = px.line(df, x = 'SampleDate', y = 'Result_Value', title = "PHEO_UGL")
fig.show()